"""
Mail of Death — Server  v1.0.0
Death's Head Software

Self-hosted bulk email backend.
Runs on your VPS. Handles campaigns, contacts, templates,
SES/SMTP delivery, bounce/complaint webhooks, and open/click tracking.

Usage:
    pip install -r requirements_server.txt
    python server.py

Environment variables:
    MOD_API_KEY        - API key for the desktop controller (required)
    MOD_DATABASE_URL   - SQLAlchemy URL (default: sqlite:///mail_of_death.db)
    MOD_BASE_URL       - Public URL of this server (for tracking pixels)
    MOD_HOST           - Bind host (default: 0.0.0.0)
    MOD_PORT           - Bind port (default: 8000)
"""
from __future__ import annotations

import os
import json
import hmac
import base64
import hashlib
import logging
import smtplib
import secrets
from datetime import datetime, timezone
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Any, Optional

from fastapi import FastAPI, HTTPException, Depends, BackgroundTasks, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, EmailStr
from sqlalchemy import (
    create_engine, Column, Integer, String, Text, DateTime,
    Boolean, Float, ForeignKey, func,
)
from sqlalchemy.orm import declarative_base, sessionmaker, Session, relationship

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("mail-of-death")

# ═══════════════════════════════════════════════════════════════════
# Config
# ═══════════════════════════════════════════════════════════════════
# ─── MANUAL CONFIGURATION ───────────────────────────────────────────
# Edit these values directly if you prefer not to use environment
# variables. Environment variables always take priority if set.
#
# Generate an API key:
#   python3 -c "import secrets; print(secrets.token_hex(32))"
# ────────────────────────────────────────────────────────────────────

MANUAL_API_KEY      = ""                           # paste your API key here
MANUAL_DATABASE_URL = "sqlite:///mail_of_death.db" # or postgresql://user:pass@localhost/dbname
MANUAL_BASE_URL     = "http://localhost:8000"      # public URL of this server
MANUAL_HOST         = "0.0.0.0"                   # bind address
MANUAL_PORT         = 8000                         # bind port

# ─── END MANUAL CONFIGURATION ───────────────────────────────────────
# Environment variables override the manual values above if set.

API_KEY      = os.environ.get("MOD_API_KEY")      or MANUAL_API_KEY      or "changeme"
DATABASE_URL = os.environ.get("MOD_DATABASE_URL") or MANUAL_DATABASE_URL
BASE_URL     = os.environ.get("MOD_BASE_URL")     or MANUAL_BASE_URL
HOST         = os.environ.get("MOD_HOST")         or MANUAL_HOST
PORT         = int(os.environ.get("MOD_PORT")     or MANUAL_PORT)
VERSION      = "1.0.0"

# ═══════════════════════════════════════════════════════════════════
# Database
# ═══════════════════════════════════════════════════════════════════
connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine  = create_engine(DATABASE_URL, connect_args=connect_args)
Session_ = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base    = declarative_base()


def get_db():
    db = Session_()
    try:
        yield db
    finally:
        db.close()


# ═══════════════════════════════════════════════════════════════════
# Models
# ═══════════════════════════════════════════════════════════════════
class ContactList(Base):
    __tablename__ = "contact_lists"
    id            = Column(Integer, primary_key=True)
    name          = Column(String(255), nullable=False, unique=True)
    description   = Column(String(500), default="")
    created_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    contacts      = relationship("Contact", back_populates="list", cascade="all, delete-orphan")


class Contact(Base):
    __tablename__ = "contacts"
    id            = Column(Integer, primary_key=True)
    list_id       = Column(Integer, ForeignKey("contact_lists.id"), nullable=False)
    email         = Column(String(255), nullable=False)
    name          = Column(String(255), default="")
    status        = Column(String(50), default="active")   # active / unsubscribed / bounced / complained
    created_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    list          = relationship("ContactList", back_populates="contacts")


class Template(Base):
    __tablename__ = "templates"
    id            = Column(Integer, primary_key=True)
    name          = Column(String(255), nullable=False, unique=True)
    body          = Column(Text, default="")
    created_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc))


class Campaign(Base):
    __tablename__ = "campaigns"
    id            = Column(Integer, primary_key=True)
    name          = Column(String(255), nullable=False)
    subject       = Column(String(500), nullable=False)
    from_name     = Column(String(255), default="")
    from_email    = Column(String(255), default="")
    list_id       = Column(Integer, ForeignKey("contact_lists.id"))
    template_id   = Column(Integer, ForeignKey("templates.id"), nullable=True)
    body          = Column(Text, default="")
    status        = Column(String(50), default="draft")   # draft / sending / sent / failed
    sent_count    = Column(Integer, default=0)
    open_rate     = Column(Float, default=0.0)
    click_rate    = Column(Float, default=0.0)
    created_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    contact_list  = relationship("ContactList")
    template      = relationship("Template")
    events        = relationship("SendEvent", back_populates="campaign", cascade="all, delete-orphan")


class SendEvent(Base):
    __tablename__  = "send_events"
    id             = Column(Integer, primary_key=True)
    campaign_id    = Column(Integer, ForeignKey("campaigns.id"))
    email          = Column(String(255))
    event_type     = Column(String(50))   # sent / delivered / open / click / bounce / complaint / unsubscribe
    detail         = Column(String(500), default="")
    timestamp      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    campaign       = relationship("Campaign", back_populates="events")


class EmailConfig(Base):
    __tablename__ = "email_config"
    id            = Column(Integer, primary_key=True)
    backend       = Column(String(50), default="ses")
    config_json   = Column(Text, default="{}")   # encrypted in a future version


class Suppression(Base):
    __tablename__ = "suppressions"
    id            = Column(Integer, primary_key=True)
    email         = Column(String(255), nullable=False, unique=True)
    reason        = Column(String(50))   # bounce / complaint / unsubscribe
    created_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc))


Base.metadata.create_all(engine)


# ═══════════════════════════════════════════════════════════════════
# Schemas
# ═══════════════════════════════════════════════════════════════════
class ListCreate(BaseModel):
    name: str
    description: str = ""


class ContactCreate(BaseModel):
    email: str
    name:  str = ""


class ContactImport(BaseModel):
    contacts: list[ContactCreate]


class CampaignCreate(BaseModel):
    name:        str
    subject:     str
    from_name:   str = ""
    from_email:  str = ""
    list_id:     int
    template_id: Optional[int] = None
    body:        str = ""


class TemplateCreate(BaseModel):
    name: str
    body: str


class EmailConfigUpdate(BaseModel):
    backend:        str = "ses"
    # SES
    ses_access:     str = ""
    ses_secret:     str = ""
    ses_region:     str = "us-east-1"
    # SMTP
    smtp_host:      str = ""
    smtp_port:      int = 587
    smtp_user:      str = ""
    smtp_pass:      str = ""
    smtp_tls:       bool = True
    # Shared
    from_email:     str = ""


# ═══════════════════════════════════════════════════════════════════
# Auth
# ═══════════════════════════════════════════════════════════════════
def require_key(request: Request):
    key = request.headers.get("X-API-Key", "")
    if not hmac.compare_digest(key, API_KEY):
        raise HTTPException(status_code=401, detail="Invalid API key")


# ═══════════════════════════════════════════════════════════════════
# Email config helpers
# ═══════════════════════════════════════════════════════════════════
def get_email_config(db: Session) -> dict:
    cfg = db.query(EmailConfig).first()
    if not cfg:
        return {}
    return json.loads(cfg.config_json)


def make_tracking_token(campaign_id: int, email: str) -> str:
    raw = f"{campaign_id}:{email}"
    # Strip = padding — safe in URL path segments and less likely to be mangled
    return base64.urlsafe_b64encode(raw.encode()).decode().rstrip("=")


def decode_tracking_token(token: str) -> tuple[int, str]:
    # Re-add padding before decoding
    padding = 4 - len(token) % 4
    if padding != 4:
        token += "=" * padding
    raw = base64.urlsafe_b64decode(token.encode()).decode()
    cid, email = raw.split(":", 1)
    return int(cid), email


def render_body(body: str, contact: Contact, campaign: Campaign, cfg: dict) -> str:
    result = body.replace("{{name}}", contact.name or contact.email.split("@")[0])
    result = result.replace("{{email}}", contact.email)
    return result


# ═══════════════════════════════════════════════════════════════════
# Delivery
# ═══════════════════════════════════════════════════════════════════
def send_via_ses(cfg: dict, to_email: str, from_email: str, subject: str, html: str):
    import boto3
    client = boto3.client(
        "ses",
        region_name=cfg.get("ses_region", "us-east-1"),
        aws_access_key_id=cfg.get("ses_access"),
        aws_secret_access_key=cfg.get("ses_secret"),
    )
    client.send_email(
        Source=from_email,
        Destination={"ToAddresses": [to_email]},
        Message={
            "Subject": {"Data": subject, "Charset": "UTF-8"},
            "Body": {
                "Html": {"Data": html, "Charset": "UTF-8"},
                "Text": {"Data": "Please view this email in an HTML-capable client.", "Charset": "UTF-8"},
            },
        },
        ConfigurationSetName=cfg.get("ses_config_set", ""),
    )


def send_via_smtp(cfg: dict, to_email: str, from_email: str, subject: str, html: str):
    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"]    = from_email
    msg["To"]      = to_email
    msg.attach(MIMEText(html, "html", "utf-8"))
    host = cfg.get("smtp_host", "")
    port = int(cfg.get("smtp_port", 587))
    user = cfg.get("smtp_user", "")
    pw   = cfg.get("smtp_pass", "")
    tls  = cfg.get("smtp_tls", True)
    with smtplib.SMTP(host, port, timeout=30) as s:
        if tls:
            s.starttls()
        if user and pw:
            s.login(user, pw)
        s.sendmail(from_email, [to_email], msg.as_string())


def send_one(cfg: dict, to_email: str, from_email: str, subject: str, html: str):
    backend = cfg.get("backend", "ses")
    if backend == "ses":
        send_via_ses(cfg, to_email, from_email, subject, html)
    else:
        send_via_smtp(cfg, to_email, from_email, subject, html)


def is_suppressed(db: Session, email: str) -> bool:
    return db.query(Suppression).filter_by(email=email.lower()).first() is not None


def suppress(db: Session, email: str, reason: str):
    email = email.lower()
    if not db.query(Suppression).filter_by(email=email).first():
        db.add(Suppression(email=email, reason=reason))
        db.commit()
    # Mark all contacts with this email
    db.query(Contact).filter(Contact.email == email).update({"status": reason})
    db.commit()


def record_event(db: Session, campaign_id: int, email: str, event_type: str, detail: str = ""):
    db.add(SendEvent(
        campaign_id=campaign_id,
        email=email,
        event_type=event_type,
        detail=detail,
        timestamp=datetime.now(timezone.utc),
    ))
    db.commit()


def recalculate_rates(db: Session, campaign_id: int):
    sent     = db.query(func.count(SendEvent.id)).filter_by(campaign_id=campaign_id, event_type="sent").scalar() or 1
    opens    = db.query(func.count(SendEvent.id)).filter_by(campaign_id=campaign_id, event_type="open").scalar()
    clicks   = db.query(func.count(SendEvent.id)).filter_by(campaign_id=campaign_id, event_type="click").scalar()
    campaign = db.get(Campaign, campaign_id)
    if campaign:
        campaign.open_rate  = round(opens  / sent * 100, 2)
        campaign.click_rate = round(clicks / sent * 100, 2)
        db.commit()


# ═══════════════════════════════════════════════════════════════════
# Background task: send campaign
# ═══════════════════════════════════════════════════════════════════
def run_campaign(campaign_id: int):
    db = Session_()
    try:
        campaign = db.get(Campaign, campaign_id)
        if not campaign:
            return
        cfg  = get_email_config(db)

        # Extract everything we need as plain Python values NOW,
        # before the send loop starts. This way deleting the campaign
        # mid-send cannot crash the task.
        body       = campaign.body
        if not body and campaign.template:
            body = campaign.template.body
        if not body:
            log.error(f"Campaign {campaign_id}: no body/template, aborting")
            campaign.status = "failed"
            db.commit()
            return

        from_email  = campaign.from_email or cfg.get("from_email", "")
        from_name   = campaign.from_name or ""
        from_line   = f"{from_name} <{from_email}>" if from_name else from_email
        subject     = campaign.subject
        list_id     = campaign.list_id

        # Snapshot subject for render_body (pass as a plain string)
        class _CampaignSnap:
            def __init__(self):
                self.id      = campaign_id
                self.subject = subject
        snap = _CampaignSnap()

        contacts = (
            db.query(Contact)
            .filter_by(list_id=list_id, status="active")
            .all()
        )

        # Mark as sending using a fresh query so we don't depend on
        # the original ORM object surviving
        db.query(Campaign).filter_by(id=campaign_id).update({"status": "sending"})
        db.commit()

        sent = 0
        for contact in contacts:
            if is_suppressed(db, contact.email):
                log.info(f"Skipping suppressed: {contact.email}")
                continue
            try:
                html = render_body(body, contact, snap, cfg)
                send_one(cfg, contact.email, from_line, subject, html)
                record_event(db, campaign_id, contact.email, "sent")
                sent += 1
            except Exception as e:
                log.error(f"Failed to send to {contact.email}: {e}")
                record_event(db, campaign_id, contact.email, "failed", str(e)[:200])

        db.query(Campaign).filter_by(id=campaign_id).update(
            {"sent_count": sent, "status": "sent"}
        )
        db.commit()
        log.info(f"Campaign {campaign_id} complete: {sent} sent")
    except Exception as e:
        log.error(f"Campaign task crashed: {e}")
        try:
            db.query(Campaign).filter_by(id=campaign_id).update({"status": "failed"})
            db.commit()
        except Exception:
            pass
    finally:
        db.close()


# ═══════════════════════════════════════════════════════════════════
# App
# ═══════════════════════════════════════════════════════════════════
app = FastAPI(title="Mail of Death API", version=VERSION)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

auth = Depends(require_key)


# ── Health ───────────────────────────────────────────────────────
@app.get("/health")
def health():
    return {"status": "ok", "version": VERSION}


@app.get("/stats", dependencies=[auth])
def stats(db: Session = Depends(get_db)):
    return {
        "total_contacts":  db.query(func.count(Contact.id)).scalar(),
        "total_lists":     db.query(func.count(ContactList.id)).scalar(),
        "total_campaigns": db.query(func.count(Campaign.id)).scalar(),
        "total_sent":      db.query(func.sum(Campaign.sent_count)).scalar() or 0,
    }


# ── Contact Lists ────────────────────────────────────────────────
@app.get("/lists", dependencies=[auth])
def list_lists(db: Session = Depends(get_db)):
    lists = db.query(ContactList).all()
    return [
        {
            "id":            l.id,
            "name":          l.name,
            "description":   l.description,
            "contact_count": len(l.contacts),
            "created_at":    l.created_at.isoformat(),
        }
        for l in lists
    ]


@app.post("/lists", dependencies=[auth])
def create_list(data: ListCreate, db: Session = Depends(get_db)):
    lst = ContactList(name=data.name, description=data.description)
    db.add(lst); db.commit(); db.refresh(lst)
    return {"id": lst.id, "name": lst.name}


@app.delete("/lists/{list_id}", dependencies=[auth])
def delete_list(list_id: int, db: Session = Depends(get_db)):
    lst = db.get(ContactList, list_id)
    if not lst:
        raise HTTPException(404, "List not found")
    db.delete(lst); db.commit()
    return {"deleted": True}


# ── Contacts ─────────────────────────────────────────────────────
@app.get("/lists/{list_id}/contacts", dependencies=[auth])
def list_contacts(list_id: int, db: Session = Depends(get_db)):
    contacts = db.query(Contact).filter_by(list_id=list_id).all()
    return [
        {
            "id":         c.id,
            "email":      c.email,
            "name":       c.name,
            "status":     c.status,
            "created_at": c.created_at.isoformat(),
        }
        for c in contacts
    ]


@app.post("/lists/{list_id}/contacts", dependencies=[auth])
def add_contact(list_id: int, data: ContactCreate, db: Session = Depends(get_db)):
    lst = db.get(ContactList, list_id)
    if not lst:
        raise HTTPException(404, "List not found")
    existing = db.query(Contact).filter_by(list_id=list_id, email=data.email).first()
    if existing:
        raise HTTPException(409, f"{data.email} is already in this list.")
    c = Contact(list_id=list_id, email=data.email.lower(), name=data.name)
    db.add(c); db.commit()
    return {"id": c.id, "email": c.email}


@app.post("/lists/{list_id}/contacts/import", dependencies=[auth])
def import_contacts(list_id: int, data: ContactImport, db: Session = Depends(get_db)):
    lst = db.get(ContactList, list_id)
    if not lst:
        raise HTTPException(404, "List not found")
    added = 0
    for ci in data.contacts:
        existing = db.query(Contact).filter_by(list_id=list_id, email=ci.email.lower()).first()
        if not existing:
            db.add(Contact(list_id=list_id, email=ci.email.lower(), name=ci.name))
            added += 1
    db.commit()
    return {"message": f"Imported {added} contacts ({len(data.contacts) - added} duplicates skipped)"}


@app.delete("/lists/{list_id}/contacts/{email}", dependencies=[auth])
def remove_contact(list_id: int, email: str, db: Session = Depends(get_db)):
    c = db.query(Contact).filter_by(list_id=list_id, email=email).first()
    if not c:
        raise HTTPException(404, "Contact not found")
    db.delete(c); db.commit()
    return {"deleted": True}


# ── Templates ─────────────────────────────────────────────────────
@app.get("/templates", dependencies=[auth])
def list_templates(db: Session = Depends(get_db)):
    return [{"id": t.id, "name": t.name, "body": t.body} for t in db.query(Template).all()]


@app.post("/templates", dependencies=[auth])
def create_template(data: TemplateCreate, db: Session = Depends(get_db)):
    existing = db.query(Template).filter_by(name=data.name).first()
    if existing:
        raise HTTPException(409, f"A template named '{data.name}' already exists. Choose a different name or delete the existing one first.")
    t = Template(name=data.name, body=data.body)
    db.add(t); db.commit()
    return {"id": t.id, "name": t.name}


@app.put("/templates/{tid}", dependencies=[auth])
def update_template(tid: int, data: TemplateCreate, db: Session = Depends(get_db)):
    t = db.get(Template, tid)
    if not t:
        raise HTTPException(404, "Template not found")
    conflict = db.query(Template).filter(Template.name == data.name, Template.id != tid).first()
    if conflict:
        raise HTTPException(409, f"A template named '{data.name}' already exists.")
    t.name = data.name; t.body = data.body
    db.commit()
    return {"id": t.id, "name": t.name}


@app.delete("/templates/{tid}", dependencies=[auth])
def delete_template(tid: int, db: Session = Depends(get_db)):
    t = db.get(Template, tid)
    if not t:
        raise HTTPException(404, "Template not found")
    db.delete(t); db.commit()
    return {"deleted": True}


# ── Campaigns ─────────────────────────────────────────────────────
@app.get("/campaigns", dependencies=[auth])
def list_campaigns(limit: int = 50, db: Session = Depends(get_db)):
    camps = db.query(Campaign).order_by(Campaign.created_at.desc()).limit(limit).all()
    return [
        {
            "id":         c.id,
            "name":       c.name,
            "subject":    c.subject,
            "status":     c.status,
            "list_name":  c.contact_list.name if c.contact_list else "",
            "sent_count": c.sent_count,
            "open_rate":  c.open_rate,
            "click_rate": c.click_rate,
            "created_at": c.created_at.isoformat(),
        }
        for c in camps
    ]


@app.post("/campaigns", dependencies=[auth])
def create_campaign(data: CampaignCreate, db: Session = Depends(get_db)):
    c = Campaign(
        name=data.name, subject=data.subject,
        from_name=data.from_name, from_email=data.from_email,
        list_id=data.list_id, template_id=data.template_id, body=data.body,
    )
    db.add(c); db.commit()
    return {"id": c.id, "name": c.name}


@app.delete("/campaigns/{cid}", dependencies=[auth])
def delete_campaign(cid: int, db: Session = Depends(get_db)):
    c = db.get(Campaign, cid)
    if not c:
        raise HTTPException(404, "Campaign not found")
    db.delete(c); db.commit()
    return {"deleted": True}


@app.post("/campaigns/{cid}/send", dependencies=[auth])
def send_campaign(cid: int, background: BackgroundTasks, db: Session = Depends(get_db)):
    c = db.get(Campaign, cid)
    if not c:
        raise HTTPException(404, "Campaign not found")
    if c.status == "sending":
        raise HTTPException(409, "Campaign is already sending")
    c.status = "queued"; db.commit()
    background.add_task(run_campaign, cid)
    return {"message": f"Campaign '{c.name}' queued for delivery"}


# ── Analytics ─────────────────────────────────────────────────────
@app.get("/analytics/campaigns/{cid}", dependencies=[auth])
def campaign_analytics(cid: int, db: Session = Depends(get_db)):
    c = db.get(Campaign, cid)
    if not c:
        raise HTTPException(404)

    def count(etype):
        return db.query(func.count(SendEvent.id)).filter_by(campaign_id=cid, event_type=etype).scalar() or 0

    events = (
        db.query(SendEvent)
        .filter_by(campaign_id=cid)
        .order_by(SendEvent.timestamp.desc())
        .limit(100)
        .all()
    )

    return {
        "sent":      count("sent"),
        "delivered": count("delivered"),
        "events": [
            {
                "timestamp":  e.timestamp.isoformat(),
                "email":      e.email,
                "event_type": e.event_type,
                "detail":     e.detail,
            }
            for e in events
        ],
    }


# ── Email config ─────────────────────────────────────────────────
@app.get("/config/email", dependencies=[auth])
def get_config(db: Session = Depends(get_db)):
    cfg = get_email_config(db)
    # Mask secrets
    masked = {k: ("***" if "secret" in k or "pass" in k else v) for k, v in cfg.items()}
    return masked


@app.put("/config/email", dependencies=[auth])
def save_config(data: EmailConfigUpdate, db: Session = Depends(get_db)):
    cfg = db.query(EmailConfig).first()
    if not cfg:
        cfg = EmailConfig()
        db.add(cfg)
    cfg.backend    = data.backend
    cfg.config_json = json.dumps(data.model_dump())
    db.commit()
    return {"saved": True}


# ── SES Webhook (SNS) ────────────────────────────────────────────
@app.post("/webhooks/ses")
async def ses_webhook(request: Request, db: Session = Depends(get_db)):
    """
    Receives SES event notifications via Amazon SNS.
    Configure SNS to POST to https://your-server/webhooks/ses
    """
    try:
        payload = await request.json()
        # SNS subscription confirmation
        if payload.get("Type") == "SubscriptionConfirmation":
            import urllib.request
            urllib.request.urlopen(payload["SubscribeURL"])
            log.info("SNS subscription confirmed")
            return {"status": "confirmed"}

        message = json.loads(payload.get("Message", "{}"))
        event_type = message.get("eventType", message.get("notificationType", ""))

        if event_type == "Bounce":
            bounce = message.get("bounce", {})
            btype  = bounce.get("bounceType", "")
            for r in bounce.get("bouncedRecipients", []):
                email = r.get("emailAddress", "")
                if btype == "Permanent":
                    suppress(db, email, "bounced")
                    log.info(f"Hard bounce suppressed: {email}")
                else:
                    # Soft bounce — just log it
                    log.info(f"Soft bounce: {email}")

        elif event_type == "Complaint":
            for r in message.get("complaint", {}).get("complainedRecipients", []):
                email = r.get("emailAddress", "")
                suppress(db, email, "complained")
                log.info(f"Complaint suppressed: {email}")

        elif event_type == "Delivery":
            mail = message.get("mail", {})
            for dest in mail.get("destination", []):
                log.info(f"Delivered: {dest}")

    except Exception as e:
        log.error(f"Webhook error: {e}")

    return {"status": "ok"}


# ═══════════════════════════════════════════════════════════════════
# Entry point
# ═══════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    import uvicorn
    log.info(f"Mail of Death Server v{VERSION}")
    log.info(f"Starting on {HOST}:{PORT}")
    if API_KEY == "changeme":
        log.warning("WARNING: Using default API key — set MANUAL_API_KEY or MOD_API_KEY!")
    uvicorn.run(app, host=HOST, port=PORT)
