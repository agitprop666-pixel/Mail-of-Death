Mail of Death is a self-hosted bulk email platform. Not for beginners. It consists of two components:
Mail of Death.exe, (or mail_of_death.py) —  a PyQt6 desktop controller that runs on your local machine.
 And server.py  —  FastAPI backend that runs on a virtual machine and handles all delivery, tracking, and data storage. The desktop app communicates with the server over HTTP/HTTPS using an API key.
All email data, contacts, and campaign history live on the server. The desktop app is purely a controller — no data is stored locally. This has been tested on a Windows 10 PC running Kali Linux in Virtualbox for the server.

The API key is a shared secret between your server and your desktop app. It is not obtained from any external service — you create it yourself. Think of it as a password that protects your mail server from unauthorised access. It is simply a password you make up and paste into the code of server.py. Open server.py in a text editor. Search for these lines in server.py.

MANUAL_API_KEY      = "API KEY "           # paste your API key here
MANUAL_DATABASE_URL = "sqlite:///mail_of_death.db" # or postgresql://user:pass@localhost/dbname
MANUAL_BASE_URL     = "http://IP Address Pasted Here:8000"      # public URL of this server
MANUAL_HOST         = "0.0.0.0"                   # bind address
MANUAL_PORT         = 8000                         # bind port

So you paste your API Key between the quotes at MANUAL_API_KEY
Use the terminal in Kali Linux and enter ifconfig to find your IP address. You paste your Kali Linux IP Address at MANUAL_BASE_URL

Setting up the server: Install Virtualbox on your PC.
(This all may possibly run on Linux or Mac if you use the source code.) Go to https://www.osboxes.org/kali-linux/
and download for Virtualbox. Run the Network setting on Virtualbox as Bridged. Once you have Kali Linux running got to: https://sourceforge.net/projects/venv-of-death/files/venv-of-death_1.0.deb.zip/download
and download VENV of Death.
Once VENV of Death is installed and running, create a new venv and install: fastapi, uvicorn, sqlalchemy, pydantic[email], boto3, psycopg2-binary
Once these are installed you can use VENV of Death to run server.py
After server.py is running you can switch to your host PC and launch Mail of Death.exe.
In the Settings tab:
  - Server URL:  http://Virtualbox IP Address:8000
  - API Key:     your- API key-here
  - Click Test Connection — should show: Connected

You can monitor Mail of Death in the console of VENV of Death. It should show any issues.I used Gmail to test, and it works. For high volume mailing try Amazon SES, which also works, or your desired bulk email provider.
The rest is self explanatory. You can use Gmail for testing, but for high volume mailing a bulk email provider is preferred. Amazon SES is recommended.

