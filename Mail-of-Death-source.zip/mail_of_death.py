"""
Mail of Death  v1.0.0
Death's Head Software

Desktop controller for the Mail of Death self-hosted bulk email platform.
Requires Mail of Death Server (server.py) running on your VPS.

Dependencies (desktop):
    pip install PyQt6 requests
"""
from __future__ import annotations

import sys
import csv
import json
import time
from pathlib import Path
from typing import Any, Callable, Optional

from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSettings, QTimer
from PyQt6.QtGui import QColor, QFont, QPainter, QPixmap
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QTextEdit, QTableWidget,
    QTableWidgetItem, QTabWidget, QSplashScreen, QMessageBox,
    QFormLayout, QComboBox, QCheckBox, QGroupBox, QFileDialog,
    QHeaderView, QDialog, QDialogButtonBox, QSizePolicy, QFrame,
    QStatusBar, QPlainTextEdit, QAbstractItemView, QListWidget,
    QSplitter, QScrollArea,
)

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

APP_NAME = "Mail of Death"
ORG_NAME = "Death's Head Software"
VERSION  = "1.0.0"

# ═══════════════════════════════════════════════════════════════════
# Stylesheet
# ═══════════════════════════════════════════════════════════════════
STYLE = """
QMainWindow, QDialog, QWidget {
    background: #0d0d0d; color: #ffffff;
    font-family: 'Courier New', monospace; font-size: 12px;
}
QTabWidget::pane { border: 1px solid #3a0000; background: #0d0d0d; }
QTabBar::tab {
    background: #1a0000; color: #ffffff;
    padding: 8px 20px; border: 1px solid #2a0000; font-weight: bold;
}
QTabBar::tab:selected { background: #2d0000; color: #ffffff; border-bottom: 2px solid #ff3333; }
QTabBar::tab:hover { background: #220000; color: #ffffff; }
QPushButton {
    background: #1a0000; color: #ffffff;
    border: 1px solid #550000; padding: 5px 14px; font-weight: bold;
}
QPushButton:hover { background: #2a0000; color: #ffffff; border-color: #aa0000; }
QPushButton:pressed { background: #3d0000; color: #ffffff; }
QPushButton:disabled { color: #555555; border-color: #222222; background: #111111; }
QLineEdit, QPlainTextEdit, QTextEdit, QSpinBox {
    background: #141414; color: #ffffff; border: 1px solid #3a0000; padding: 4px;
}
QLineEdit:focus, QPlainTextEdit:focus, QTextEdit:focus { border: 1px solid #aa0000; }
QComboBox { background: #141414; color: #ffffff; border: 1px solid #3a0000; padding: 4px; }
QComboBox QAbstractItemView {
    background: #1a1a1a; color: #ffffff;
    border: 1px solid #3a0000; selection-background-color: #2a0000;
}
QTableWidget {
    background: #0d0d0d; color: #ffffff;
    border: 1px solid #3a0000; gridline-color: #1e1e1e;
}
QTableWidget::item:selected { background: #2a0000; color: #ffffff; }
QHeaderView::section {
    background: #1a0000; color: #ffffff;
    border: 1px solid #2a0000; padding: 4px 8px; font-weight: bold;
}
QListWidget { background: #0d0d0d; color: #ffffff; border: 1px solid #3a0000; }
QListWidget::item:selected { background: #2a0000; color: #ffffff; }
QGroupBox {
    border: 1px solid #3a0000; color: #ffffff;
    font-weight: bold; margin-top: 14px; padding-top: 8px;
}
QGroupBox::title { subcontrol-origin: margin; subcontrol-position: top left; padding: 0 6px; }
QLabel { color: #ffffff; }
QScrollBar:vertical { background: #0d0d0d; width: 10px; border: none; }
QScrollBar::handle:vertical { background: #2a0000; min-height: 20px; }
QScrollBar::handle:vertical:hover { background: #440000; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QStatusBar { background: #0a0a0a; color: #ffffff; border-top: 1px solid #2a0000; }
QCheckBox { color: #ffffff; spacing: 8px; }
QCheckBox::indicator { border: 1px solid #550000; background: #141414; width: 14px; height: 14px; }
QCheckBox::indicator:checked { background: #8b0000; border-color: #aa0000; }
QSplitter::handle { background: #2a0000; }
"""

# ═══════════════════════════════════════════════════════════════════
# Resource path (PyInstaller safe)
# ═══════════════════════════════════════════════════════════════════
def resource_path(rel: str) -> Path:
    if hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS) / rel
    return Path(__file__).parent / rel


# ═══════════════════════════════════════════════════════════════════
# Splash screen
# ═══════════════════════════════════════════════════════════════════
def create_splash() -> Optional[QSplashScreen]:
    try:
        png = resource_path("splash.png")
        if png.exists():
            pm = QPixmap(str(png))
            if pm.isNull():
                pm = QPixmap(800, 600)
                pm.fill(QColor(13, 13, 13))
            pm = pm.scaled(
                800, 600,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
        else:
            pm = QPixmap(800, 600)
            pm.fill(QColor(13, 13, 13))

        p = QPainter(pm)

        # Title
        p.setPen(QColor(255, 255, 255))
        p.setFont(QFont("Courier", 38, QFont.Weight.Bold))
        r = pm.rect(); r.setTop(40); r.setBottom(120)
        p.drawText(r, Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)

        # Skull fallback
        if not png.exists():
            p.setFont(QFont("Courier", 13))
            skull = [
                "      ___________     ",
                "     /           \\   ",
                "    |  O       O  |  ",
                "    |      ^      |  ",
                "    |   \\_____/   |  ",
                "     \\_         _/   ",
                "       |_______|     ",
            ]
            for i, line in enumerate(skull):
                p.drawText(225, 248 + i * 26, line)

        # Footer
        p.setPen(QColor(255, 255, 255))
        p.setFont(QFont("Courier", 14, QFont.Weight.Bold))
        r2 = pm.rect(); r2.setTop(pm.height() - 70); r2.setBottom(pm.height() - 20)
        p.drawText(r2, Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
        p.end()

        return QSplashScreen(pm, Qt.WindowType.WindowStaysOnTopHint)
    except Exception:
        return None


# ═══════════════════════════════════════════════════════════════════
# App icon (taskbar + title bar)
# ═══════════════════════════════════════════════════════════════════
def create_icon():
    """
    Returns a QIcon. Tries icon.ico then icon.png from the app directory.
    Falls back to a programmatically drawn skull on a dark background.
    """
    from PyQt6.QtGui import QIcon
    for name in ("icon.ico", "icon.png"):
        path = resource_path(name)
        if path.exists():
            icon = QIcon(str(path))
            if not icon.isNull():
                return icon

    # Draw a simple skull icon at 64×64
    pm = QPixmap(64, 64)
    pm.fill(QColor(0, 0, 0, 0))          # transparent background
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)

    # Dark rounded background
    p.setBrush(QColor(20, 0, 0))
    p.setPen(QColor(140, 0, 0))
    p.drawRoundedRect(2, 2, 60, 60, 10, 10)

    # Skull dome
    p.setBrush(QColor(220, 220, 220))
    p.setPen(QColor(180, 180, 180))
    p.drawEllipse(12, 8, 40, 36)

    # Jaw
    p.setBrush(QColor(210, 210, 210))
    p.drawRoundedRect(16, 36, 32, 16, 4, 4)

    # Eye sockets
    p.setBrush(QColor(20, 0, 0))
    p.setPen(Qt.PenStyle.NoPen)
    p.drawEllipse(17, 18, 11, 11)
    p.drawEllipse(36, 18, 11, 11)

    # Nose cavity
    p.drawRoundedRect(28, 30, 8, 7, 2, 2)

    # Teeth
    p.setBrush(QColor(240, 240, 240))
    for tx in (18, 25, 32, 39):
        p.drawRect(tx, 44, 5, 6)

    p.end()
    from PyQt6.QtGui import QIcon
    return QIcon(pm)


# ═══════════════════════════════════════════════════════════════════
# API Client
# ═══════════════════════════════════════════════════════════════════
class APIClient:
    def __init__(self):
        self.base_url = ""
        self.api_key  = ""

    def _h(self):
        return {"X-API-Key": self.api_key, "Content-Type": "application/json"}

    @staticmethod
    def _raise(r):
        """Raise with the server's detail message when available."""
        try:
            r.raise_for_status()
        except requests.exceptions.HTTPError:
            msg = ""
            try:
                msg = r.json().get("detail", "")
            except Exception:
                pass
            if not msg:
                msg = f"HTTP {r.status_code}"
            raise RuntimeError(msg)

    def get(self, path: str, **kw) -> Any:
        r = requests.get(f"{self.base_url}{path}", headers=self._h(), timeout=10, **kw)
        self._raise(r); return r.json()

    def post(self, path: str, data: Any = None, **kw) -> Any:
        r = requests.post(f"{self.base_url}{path}", json=data, headers=self._h(), timeout=10, **kw)
        self._raise(r); return r.json()

    def put(self, path: str, data: Any = None, **kw) -> Any:
        r = requests.put(f"{self.base_url}{path}", json=data, headers=self._h(), timeout=10, **kw)
        self._raise(r); return r.json()

    def delete(self, path: str, **kw) -> Any:
        r = requests.delete(f"{self.base_url}{path}", headers=self._h(), timeout=10, **kw)
        self._raise(r); return r.json()

    def ping(self) -> bool:
        try:
            self.get("/health"); return True
        except Exception:
            return False


# ═══════════════════════════════════════════════════════════════════
# Generic worker thread
# ═══════════════════════════════════════════════════════════════════
class ApiWorker(QThread):
    result = pyqtSignal(object)
    error  = pyqtSignal(str)

    def __init__(self, fn: Callable, *args, **kwargs):
        super().__init__()
        self._fn, self._a, self._kw = fn, args, kwargs

    def run(self):
        try:
            self.result.emit(self._fn(*self._a, **self._kw))
        except Exception as e:
            self.error.emit(str(e))


# ═══════════════════════════════════════════════════════════════════
# Reusable table helper
# ═══════════════════════════════════════════════════════════════════
def make_table(headers: list[str]) -> QTableWidget:
    t = QTableWidget(0, len(headers))
    t.setHorizontalHeaderLabels(headers)
    t.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
    t.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
    t.horizontalHeader().setStretchLastSection(True)
    t.verticalHeader().setVisible(False)
    return t


def table_row(table: QTableWidget, values: list[str]):
    row = table.rowCount(); table.insertRow(row)
    for col, val in enumerate(values):
        item = QTableWidgetItem(str(val))
        item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        table.setItem(row, col, item)


# ═══════════════════════════════════════════════════════════════════
# Dialogs
# ═══════════════════════════════════════════════════════════════════
class NewCampaignDialog(QDialog):
    def __init__(self, api: APIClient, parent=None):
        super().__init__(parent)
        self.api = api
        self.setWindowTitle("New Campaign")
        self.setMinimumWidth(500)
        self._lists     = {}
        self._templates = {}
        self._build()
        self._load_data()

    def _build(self):
        layout = QVBoxLayout(self)

        form = QFormLayout()
        self.name_edit    = QLineEdit()
        self.subject_edit = QLineEdit()
        self.from_name    = QLineEdit()
        self.from_email   = QLineEdit()
        self.list_combo   = QComboBox()
        self.tmpl_combo   = QComboBox()
        self.tmpl_combo.addItem("(None — use inline body)", None)

        form.addRow("Campaign name:", self.name_edit)
        form.addRow("Subject:", self.subject_edit)
        form.addRow("From name:", self.from_name)
        form.addRow("From email:", self.from_email)
        form.addRow("Contact list:", self.list_combo)
        form.addRow("Template:", self.tmpl_combo)
        layout.addLayout(form)

        layout.addWidget(QLabel("HTML body (leave blank to use template):"))
        self.body_edit = QPlainTextEdit()
        self.body_edit.setPlaceholderText("<h1>Hello {{name}}</h1>\n<p>Your message here.</p>")
        self.body_edit.setMinimumHeight(150)
        layout.addWidget(self.body_edit)

        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        btns.accepted.connect(self._validate)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def _load_data(self):
        try:
            lists = self.api.get("/lists")
            for lst in lists:
                self._lists[lst["name"]] = lst["id"]
                self.list_combo.addItem(lst["name"], lst["id"])
        except Exception:
            pass
        try:
            tmpls = self.api.get("/templates")
            for t in tmpls:
                self._templates[t["name"]] = t["id"]
                self.tmpl_combo.addItem(t["name"], t["id"])
        except Exception:
            pass

    def _validate(self):
        if not self.name_edit.text().strip():
            QMessageBox.warning(self, "Validation", "Campaign name is required.")
            return
        if not self.subject_edit.text().strip():
            QMessageBox.warning(self, "Validation", "Subject is required.")
            return
        if self.list_combo.count() == 0:
            QMessageBox.warning(self, "Validation", "No contact lists found. Create one first.")
            return
        self.accept()

    def get_data(self) -> dict:
        return {
            "name":        self.name_edit.text().strip(),
            "subject":     self.subject_edit.text().strip(),
            "from_name":   self.from_name.text().strip(),
            "from_email":  self.from_email.text().strip(),
            "list_id":     self.list_combo.currentData(),
            "template_id": self.tmpl_combo.currentData(),
            "body":        self.body_edit.toPlainText().strip(),
        }


class NewListDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("New Contact List")
        layout = QFormLayout(self)
        self.name_edit = QLineEdit()
        self.desc_edit = QLineEdit()
        layout.addRow("List name:", self.name_edit)
        layout.addRow("Description:", self.desc_edit)
        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addRow(btns)

    def get_data(self) -> dict:
        return {"name": self.name_edit.text().strip(), "description": self.desc_edit.text().strip()}


class AddContactDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Add Contact")
        layout = QFormLayout(self)
        self.email_edit = QLineEdit()
        self.name_edit  = QLineEdit()
        layout.addRow("Email:", self.email_edit)
        layout.addRow("Name:", self.name_edit)
        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addRow(btns)

    def get_data(self) -> dict:
        return {"email": self.email_edit.text().strip(), "name": self.name_edit.text().strip()}


# ═══════════════════════════════════════════════════════════════════
# Stat card widget (Dashboard)
# ═══════════════════════════════════════════════════════════════════
class StatCard(QFrame):
    def __init__(self, label: str):
        super().__init__()
        self.setFrameShape(QFrame.Shape.Box)
        self.setStyleSheet("QFrame { border: 1px solid #3a0000; background: #111111; padding: 6px; }")
        self.setMinimumWidth(150)
        lay = QVBoxLayout(self)
        lay.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._val = QLabel("—")
        self._val.setStyleSheet("color: #ffffff; font-size: 28px; font-weight: bold; font-family: 'Courier New';")
        self._val.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._lbl = QLabel(label.upper())
        self._lbl.setStyleSheet("color: #aaaaaa; font-size: 10px; font-family: 'Courier New';")
        self._lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self._val)
        lay.addWidget(self._lbl)

    def set_value(self, v: str):
        self._val.setText(v)


# ═══════════════════════════════════════════════════════════════════
# Dashboard Tab
# ═══════════════════════════════════════════════════════════════════
class DashboardTab(QWidget):
    def __init__(self, api: APIClient):
        super().__init__()
        self.api = api
        self._build()
        self._timer = QTimer(self)
        self._timer.timeout.connect(self.refresh)
        self._timer.start(30_000)

    def _build(self):
        layout = QVBoxLayout(self)

        # Status bar
        status_row = QHBoxLayout()
        self._status_dot   = QLabel("●")
        self._status_label = QLabel("Not connected")
        self._status_dot.setStyleSheet("color: #ff4444; font-size: 18px;")
        self._refresh_btn  = QPushButton("↻  Refresh")
        self._refresh_btn.clicked.connect(self.refresh)
        status_row.addWidget(self._status_dot)
        status_row.addWidget(self._status_label)
        status_row.addStretch()
        status_row.addWidget(self._refresh_btn)
        layout.addLayout(status_row)

        # Stat cards
        cards_row = QHBoxLayout()
        self._card_contacts  = StatCard("Total Contacts")
        self._card_lists     = StatCard("Lists")
        self._card_campaigns = StatCard("Campaigns")
        self._card_sent      = StatCard("Emails Sent")
        for c in (self._card_contacts, self._card_lists, self._card_campaigns, self._card_sent):
            cards_row.addWidget(c)
        layout.addLayout(cards_row)

        # Recent campaigns
        layout.addWidget(QLabel("Recent Campaigns"))
        self._table = make_table(["Name", "Subject", "Status", "Sent", "Opens", "Clicks"])
        layout.addWidget(self._table)

    def refresh(self):
        if not self.api.base_url:
            return
        self._w = ApiWorker(self._fetch)
        self._w.result.connect(self._apply)
        self._w.error.connect(self._on_error)
        self._w.start()

    def _fetch(self):
        return {
            "ping":      self.api.ping(),
            "stats":     self.api.get("/stats"),
            "campaigns": self.api.get("/campaigns?limit=10"),
        }

    def _apply(self, data: dict):
        if data["ping"]:
            self._status_dot.setStyleSheet("color: #44ff44; font-size: 18px;")
            self._status_label.setText("Connected")
        else:
            self._status_dot.setStyleSheet("color: #ff4444; font-size: 18px;")
            self._status_label.setText("Server unreachable")
            return

        s = data["stats"]
        self._card_contacts.set_value(str(s.get("total_contacts", 0)))
        self._card_lists.set_value(str(s.get("total_lists", 0)))
        self._card_campaigns.set_value(str(s.get("total_campaigns", 0)))
        self._card_sent.set_value(str(s.get("total_sent", 0)))

        self._table.setRowCount(0)
        for c in data["campaigns"]:
            table_row(self._table, [
                c.get("name", ""),
                c.get("subject", ""),
                c.get("status", ""),
                str(c.get("sent_count", 0)),
                f"{c.get('open_rate', 0):.1f}%",
                f"{c.get('click_rate', 0):.1f}%",
            ])

    def _on_error(self, msg: str):
        self._status_dot.setStyleSheet("color: #ff4444; font-size: 18px;")
        self._status_label.setText(f"Error: {msg}")


# ═══════════════════════════════════════════════════════════════════
# Campaigns Tab
# ═══════════════════════════════════════════════════════════════════
class CampaignsTab(QWidget):
    def __init__(self, api: APIClient):
        super().__init__()
        self.api = api
        self._campaigns: list[dict] = []
        self._build()

    def _build(self):
        layout = QVBoxLayout(self)

        btn_row = QHBoxLayout()
        self._new_btn    = QPushButton("+ New Campaign")
        self._send_btn   = QPushButton("▶  Send Now")
        self._delete_btn = QPushButton("✕  Delete")
        self._refresh_btn = QPushButton("↻  Refresh")
        self._send_btn.setEnabled(False)
        self._delete_btn.setEnabled(False)
        for b in (self._new_btn, self._send_btn, self._delete_btn, self._refresh_btn):
            btn_row.addWidget(b)
        btn_row.addStretch()
        layout.addLayout(btn_row)

        self._table = make_table(["Name", "Subject", "Status", "List", "Sent", "Created"])
        self._table.itemSelectionChanged.connect(self._on_selection)
        layout.addWidget(self._table)

        self._new_btn.clicked.connect(self._new_campaign)
        self._send_btn.clicked.connect(self._send_campaign)
        self._delete_btn.clicked.connect(self._delete_campaign)
        self._refresh_btn.clicked.connect(self.refresh)

    def refresh(self):
        if not self.api.base_url:
            return
        self._w = ApiWorker(self.api.get, "/campaigns")
        self._w.result.connect(self._apply)
        self._w.error.connect(lambda e: QMessageBox.warning(self, "Error", e))
        self._w.start()

    def _apply(self, campaigns: list):
        self._campaigns = campaigns
        self._table.setRowCount(0)
        for c in campaigns:
            table_row(self._table, [
                c.get("name", ""),
                c.get("subject", ""),
                c.get("status", "draft"),
                c.get("list_name", ""),
                str(c.get("sent_count", 0)),
                c.get("created_at", "")[:10],
            ])

    def _on_selection(self):
        has = bool(self._table.selectedItems())
        self._send_btn.setEnabled(has)
        self._delete_btn.setEnabled(has)

    def _selected_id(self) -> Optional[int]:
        row = self._table.currentRow()
        if row < 0 or row >= len(self._campaigns):
            return None
        return self._campaigns[row]["id"]

    def _new_campaign(self):
        dlg = NewCampaignDialog(self.api, self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            data = dlg.get_data()
            self._w2 = ApiWorker(self.api.post, "/campaigns", data)
            self._w2.result.connect(lambda _: self.refresh())
            self._w2.error.connect(lambda e: QMessageBox.critical(self, "Error", e))
            self._w2.start()

    def _send_campaign(self):
        cid = self._selected_id()
        if cid is None:
            return
        row  = self._table.currentRow()
        name = self._campaigns[row].get("name", "")
        ans  = QMessageBox.question(
            self, "Confirm Send",
            f"Send campaign '{name}' now?\n\nThis will email all contacts in the list.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if ans != QMessageBox.StandardButton.Yes:
            return
        self._w3 = ApiWorker(self.api.post, f"/campaigns/{cid}/send")
        self._w3.result.connect(lambda r: (
            QMessageBox.information(self, "Queued", r.get("message", "Campaign queued.")),
            self.refresh(),
        ))
        self._w3.error.connect(lambda e: QMessageBox.critical(self, "Error", e))
        self._w3.start()

    def _delete_campaign(self):
        cid = self._selected_id()
        if cid is None:
            return
        row  = self._table.currentRow()
        name = self._campaigns[row].get("name", "")
        ans  = QMessageBox.question(
            self, "Confirm Delete", f"Delete campaign '{name}'?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if ans != QMessageBox.StandardButton.Yes:
            return
        self._w4 = ApiWorker(self.api.delete, f"/campaigns/{cid}")
        self._w4.result.connect(lambda _: self.refresh())
        self._w4.error.connect(lambda e: QMessageBox.critical(self, "Error", e))
        self._w4.start()


# ═══════════════════════════════════════════════════════════════════
# Contacts Tab
# ═══════════════════════════════════════════════════════════════════
class ContactsTab(QWidget):
    def __init__(self, api: APIClient):
        super().__init__()
        self.api = api
        self._lists: list[dict] = []
        self._build()

    def _build(self):
        layout = QHBoxLayout(self)
        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Left: List management
        left = QWidget()
        llayout = QVBoxLayout(left)
        llayout.addWidget(QLabel("Contact Lists"))
        self._list_widget = QListWidget()
        self._list_widget.currentRowChanged.connect(self._on_list_selected)
        llayout.addWidget(self._list_widget)
        list_btns = QHBoxLayout()
        self._new_list_btn = QPushButton("+ List")
        self._del_list_btn = QPushButton("✕")
        self._del_list_btn.setEnabled(False)
        list_btns.addWidget(self._new_list_btn)
        list_btns.addWidget(self._del_list_btn)
        llayout.addLayout(list_btns)
        left.setMaximumWidth(220)

        # Right: Contacts in selected list
        right = QWidget()
        rlayout = QVBoxLayout(right)
        rlayout.addWidget(QLabel("Contacts"))
        contact_btns = QHBoxLayout()
        self._add_contact_btn    = QPushButton("+ Add")
        self._remove_contact_btn = QPushButton("✕ Remove")
        self._import_btn         = QPushButton("↑ Import")
        self._export_btn         = QPushButton("↓ Export")
        self._refresh_btn        = QPushButton("↻")
        for b in (self._add_contact_btn, self._remove_contact_btn,
                  self._import_btn, self._export_btn, self._refresh_btn):
            contact_btns.addWidget(b)
        contact_btns.addStretch()
        rlayout.addLayout(contact_btns)
        self._contact_table = make_table(["Email", "Name", "Status", "Subscribed"])
        rlayout.addWidget(self._contact_table)

        splitter.addWidget(left)
        splitter.addWidget(right)
        splitter.setSizes([200, 700])
        layout.addWidget(splitter)

        # Connect
        self._new_list_btn.clicked.connect(self._new_list)
        self._del_list_btn.clicked.connect(self._delete_list)
        self._add_contact_btn.clicked.connect(self._add_contact)
        self._remove_contact_btn.clicked.connect(self._remove_contact)
        self._import_btn.clicked.connect(self._import_csv)
        self._export_btn.clicked.connect(self._export_csv)
        self._refresh_btn.clicked.connect(self._reload_contacts)

    def refresh(self):
        if not self.api.base_url:
            return
        self._w = ApiWorker(self.api.get, "/lists")
        self._w.result.connect(self._apply_lists)
        self._w.error.connect(lambda e: QMessageBox.warning(self, "Error", e))
        self._w.start()

    def _apply_lists(self, lists: list):
        self._lists = lists
        self._list_widget.clear()
        for lst in lists:
            self._list_widget.addItem(f"{lst['name']} ({lst.get('contact_count', 0)})")
        self._del_list_btn.setEnabled(bool(lists))

    def _on_list_selected(self, row: int):
        if row < 0 or row >= len(self._lists):
            return
        self._reload_contacts()

    def _current_list_id(self) -> Optional[int]:
        row = self._list_widget.currentRow()
        if row < 0 or row >= len(self._lists):
            return None
        return self._lists[row]["id"]

    def _reload_contacts(self):
        lid = self._current_list_id()
        if lid is None:
            return
        self._wc = ApiWorker(self.api.get, f"/lists/{lid}/contacts")
        self._wc.result.connect(self._apply_contacts)
        self._wc.error.connect(lambda e: QMessageBox.warning(self, "Error", e))
        self._wc.start()

    def _apply_contacts(self, contacts: list):
        self._contact_table.setRowCount(0)
        for c in contacts:
            table_row(self._contact_table, [
                c.get("email", ""),
                c.get("name", ""),
                c.get("status", "active"),
                c.get("created_at", "")[:10],
            ])

    def _new_list(self):
        dlg = NewListDialog(self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            data = dlg.get_data()
            if not data["name"]:
                return
            self._wn = ApiWorker(self.api.post, "/lists", data)
            self._wn.result.connect(lambda _: self.refresh())
            self._wn.error.connect(lambda e: QMessageBox.critical(self, "Error", e))
            self._wn.start()

    def _delete_list(self):
        lid = self._current_list_id()
        if lid is None:
            return
        row  = self._list_widget.currentRow()
        name = self._lists[row]["name"]
        ans  = QMessageBox.question(
            self, "Confirm", f"Delete list '{name}' and all its contacts?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if ans != QMessageBox.StandardButton.Yes:
            return
        self._wd = ApiWorker(self.api.delete, f"/lists/{lid}")
        self._wd.result.connect(lambda _: self.refresh())
        self._wd.error.connect(lambda e: QMessageBox.critical(self, "Error", e))
        self._wd.start()

    def _add_contact(self):
        lid = self._current_list_id()
        if lid is None:
            QMessageBox.warning(self, "No List", "Select a contact list first.")
            return
        dlg = AddContactDialog(self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            data = dlg.get_data()
            if not data["email"]:
                return
            self._wa = ApiWorker(self.api.post, f"/lists/{lid}/contacts", data)
            self._wa.result.connect(lambda _: self._reload_contacts())
            self._wa.error.connect(lambda e: QMessageBox.critical(self, "Error", e))
            self._wa.start()

    def _remove_contact(self):
        lid = self._current_list_id()
        row = self._contact_table.currentRow()
        if lid is None or row < 0:
            return
        email_item = self._contact_table.item(row, 0)
        if email_item is None:
            return
        email = email_item.text()
        ans   = QMessageBox.question(
            self, "Confirm", f"Remove {email} from this list?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if ans != QMessageBox.StandardButton.Yes:
            return
        self._wr = ApiWorker(self.api.delete, f"/lists/{lid}/contacts/{email}")
        self._wr.result.connect(lambda _: self._reload_contacts())
        self._wr.error.connect(lambda e: QMessageBox.critical(self, "Error", e))
        self._wr.start()

    def _import_csv(self):
        lid = self._current_list_id()
        if lid is None:
            QMessageBox.warning(self, "No List", "Select a contact list first.")
            return
        path, _ = QFileDialog.getOpenFileName(self, "Import Contacts", "", "Text Files (*.txt)")
        if not path:
            return
        contacts = []
        try:
            with open(path, encoding="utf-8") as f:
                content = f.read()
            # Split on any combination of commas, newlines, and whitespace
            raw_tokens = [t.strip() for t in content.replace("\n", ",").split(",")]
            for token in raw_tokens:
                token = token.strip()
                if not token:
                    continue
                # If it looks like a header row word, skip it
                if token.lower() in ("email", "name", "status", "subscribed"):
                    continue
                # Basic email sanity check
                if "@" in token and "." in token.split("@")[-1]:
                    contacts.append({"email": token.lower(), "name": ""})
        except Exception as e:
            QMessageBox.critical(self, "Import Error", str(e))
            return
        if not contacts:
            QMessageBox.warning(self, "Empty", "No valid email addresses found in file.")
            return
        self._wi = ApiWorker(self.api.post, f"/lists/{lid}/contacts/import", {"contacts": contacts})
        self._wi.result.connect(lambda r: (
            QMessageBox.information(self, "Imported", r.get("message", f"Imported {len(contacts)} contacts.")),
            self._reload_contacts(),
        ))
        self._wi.error.connect(lambda e: QMessageBox.critical(self, "Error", e))
        self._wi.start()

    def _export_csv(self):
        lid = self._current_list_id()
        if lid is None:
            return
        path, _ = QFileDialog.getSaveFileName(self, "Export Contacts", "contacts.txt", "Text Files (*.txt)")
        if not path:
            return
        rows = self._contact_table.rowCount()
        try:
            emails = [
                self._contact_table.item(r, 0).text()
                for r in range(rows)
                if self._contact_table.item(r, 0)
            ]
            with open(path, "w", encoding="utf-8") as f:
                f.write(",".join(emails))
            QMessageBox.information(self, "Exported", f"Exported {len(emails)} addresses to {path}")
        except Exception as e:
            QMessageBox.critical(self, "Export Error", str(e))


# ═══════════════════════════════════════════════════════════════════
# Templates Tab
# ═══════════════════════════════════════════════════════════════════
class TemplatesTab(QWidget):
    def __init__(self, api: APIClient):
        super().__init__()
        self.api = api
        self._templates: list[dict] = []
        self._build()

    def _build(self):
        layout = QHBoxLayout(self)
        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Left: template list
        left = QWidget()
        ll = QVBoxLayout(left)
        ll.addWidget(QLabel("Templates"))
        self._list = QListWidget()
        self._list.currentRowChanged.connect(self._on_select)
        ll.addWidget(self._list)
        lbtns = QHBoxLayout()
        self._new_btn = QPushButton("+ New")
        self._del_btn = QPushButton("✕")
        lbtns.addWidget(self._new_btn)
        lbtns.addWidget(self._del_btn)
        ll.addLayout(lbtns)
        left.setMaximumWidth(220)

        # Right: editor
        right = QWidget()
        rl = QVBoxLayout(right)
        name_row = QHBoxLayout()
        name_row.addWidget(QLabel("Name:"))
        self._name_edit = QLineEdit()
        name_row.addWidget(self._name_edit)
        self._save_btn = QPushButton("💾  Save")
        name_row.addWidget(self._save_btn)
        rl.addLayout(name_row)
        rl.addWidget(QLabel("HTML Body (use {{name}}, {{email}}, {{unsubscribe_url}}):"))
        self._editor = QPlainTextEdit()
        self._editor.setPlaceholderText("<h1>Hello {{name}}</h1>\n<p>Content here.</p>\n<p><a href='{{unsubscribe_url}}'>Unsubscribe</a></p>")
        rl.addWidget(self._editor)

        splitter.addWidget(left)
        splitter.addWidget(right)
        splitter.setSizes([200, 700])
        layout.addWidget(splitter)

        self._new_btn.clicked.connect(self._new_template)
        self._del_btn.clicked.connect(self._delete_template)
        self._save_btn.clicked.connect(self._save_template)

    def refresh(self):
        if not self.api.base_url:
            return
        self._w = ApiWorker(self.api.get, "/templates")
        self._w.result.connect(self._apply)
        self._w.error.connect(lambda e: QMessageBox.warning(self, "Error", e))
        self._w.start()

    def _apply(self, templates: list):
        self._templates = templates
        self._list.clear()
        for t in templates:
            self._list.addItem(t["name"])

    def _on_select(self, row: int):
        if row < 0 or row >= len(self._templates):
            return
        t = self._templates[row]
        self._name_edit.setText(t.get("name", ""))
        self._editor.setPlainText(t.get("body", ""))

    def _new_template(self):
        self._list.clearSelection()
        self._name_edit.setText("New Template")
        self._editor.setPlainText("<h1>Hello {{name}}</h1>\n<p>Content here.</p>")

    def _save_template(self):
        name = self._name_edit.text().strip()
        body = self._editor.toPlainText().strip()
        if not name or not body:
            QMessageBox.warning(self, "Validation", "Name and body are required.")
            return
        row = self._list.currentRow()
        if row >= 0 and row < len(self._templates):
            tid  = self._templates[row]["id"]
            self._ws = ApiWorker(self.api.put, f"/templates/{tid}", {"name": name, "body": body})
        else:
            self._ws = ApiWorker(self.api.post, "/templates", {"name": name, "body": body})
        self._ws.result.connect(lambda _: self.refresh())
        self._ws.error.connect(lambda e: QMessageBox.critical(self, "Error", e))
        self._ws.start()

    def _delete_template(self):
        row = self._list.currentRow()
        if row < 0 or row >= len(self._templates):
            return
        name = self._templates[row]["name"]
        ans  = QMessageBox.question(
            self, "Confirm", f"Delete template '{name}'?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if ans != QMessageBox.StandardButton.Yes:
            return
        tid = self._templates[row]["id"]
        self._wd = ApiWorker(self.api.delete, f"/templates/{tid}")
        self._wd.result.connect(lambda _: self.refresh())
        self._wd.error.connect(lambda e: QMessageBox.critical(self, "Error", e))
        self._wd.start()


# ═══════════════════════════════════════════════════════════════════
# Analytics Tab
# ═══════════════════════════════════════════════════════════════════
class AnalyticsTab(QWidget):
    def __init__(self, api: APIClient):
        super().__init__()
        self.api = api
        self._campaigns: list[dict] = []
        self._build()

    def _build(self):
        layout = QVBoxLayout(self)

        top = QHBoxLayout()
        top.addWidget(QLabel("Campaign:"))
        self._campaign_combo = QComboBox()
        self._campaign_combo.setMinimumWidth(300)
        self._load_btn = QPushButton("Load Stats")
        top.addWidget(self._campaign_combo)
        top.addWidget(self._load_btn)
        top.addStretch()
        layout.addLayout(top)

        # Stat cards — sent only
        cards = QHBoxLayout()
        self._c_sent = StatCard("Sent")
        cards.addWidget(self._c_sent)
        cards.addStretch()
        layout.addLayout(cards)

        layout.addWidget(QLabel("Send Events"))
        self._events_table = make_table(["Time", "Email", "Event", "Detail"])
        layout.addWidget(self._events_table)

        self._load_btn.clicked.connect(self._load_stats)

    def refresh(self):
        if not self.api.base_url:
            return
        self._wc = ApiWorker(self.api.get, "/campaigns")
        self._wc.result.connect(self._apply_campaigns)
        self._wc.error.connect(lambda e: None)
        self._wc.start()

    def _apply_campaigns(self, campaigns: list):
        self._campaigns = campaigns
        self._campaign_combo.clear()
        for c in campaigns:
            self._campaign_combo.addItem(c["name"], c["id"])

    def _load_stats(self):
        cid = self._campaign_combo.currentData()
        if cid is None:
            return
        self._ws = ApiWorker(self.api.get, f"/analytics/campaigns/{cid}")
        self._ws.result.connect(self._apply_stats)
        self._ws.error.connect(lambda e: QMessageBox.warning(self, "Error", e))
        self._ws.start()

    def _apply_stats(self, data: dict):
        self._c_sent.set_value(str(data.get("sent", 0)))

        self._events_table.setRowCount(0)
        for ev in data.get("events", []):
            table_row(self._events_table, [
                ev.get("timestamp", "")[:19],
                ev.get("email", ""),
                ev.get("event_type", ""),
                ev.get("detail", ""),
            ])


# ═══════════════════════════════════════════════════════════════════
# Settings Tab
# ═══════════════════════════════════════════════════════════════════
class SettingsTab(QWidget):
    settings_saved = pyqtSignal(str, str)   # base_url, api_key

    def __init__(self, api: APIClient, qsettings: QSettings):
        super().__init__()
        self.api  = api
        self._qs  = qsettings
        self._build()
        self._load()

    def _build(self):
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        container = QWidget()
        scroll.setWidget(container)
        outer = QVBoxLayout(self)
        outer.addWidget(scroll)

        layout = QVBoxLayout(container)
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)

        # ── Server ──────────────────────────────────────────────
        srv_grp = QGroupBox("Server Connection")
        srv_form = QFormLayout(srv_grp)
        self._url_edit = QLineEdit()
        self._url_edit.setPlaceholderText("https://your-vps.com:8000")
        self._key_edit = QLineEdit()
        self._key_edit.setPlaceholderText("your-api-key")
        self._key_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self._ping_btn = QPushButton("Test Connection")
        self._ping_lbl = QLabel("")
        srv_form.addRow("Server URL:", self._url_edit)
        srv_form.addRow("API Key:", self._key_edit)
        srv_form.addRow("", self._ping_btn)
        srv_form.addRow("", self._ping_lbl)
        layout.addWidget(srv_grp)

        # ── Email Backend ────────────────────────────────────────
        mail_grp = QGroupBox("Email Backend")
        ml = QVBoxLayout(mail_grp)
        backend_row = QHBoxLayout()
        backend_row.addWidget(QLabel("Backend:"))
        self._backend_combo = QComboBox()
        self._backend_combo.addItems(["Amazon SES", "SMTP"])
        self._backend_combo.currentIndexChanged.connect(self._on_backend_change)
        backend_row.addWidget(self._backend_combo)
        backend_row.addStretch()
        ml.addLayout(backend_row)

        # SES fields
        self._ses_widget = QWidget()
        ses_form = QFormLayout(self._ses_widget)
        self._ses_access  = QLineEdit(); self._ses_access.setPlaceholderText("AKIAIOSFODNN7EXAMPLE")
        self._ses_secret  = QLineEdit(); self._ses_secret.setEchoMode(QLineEdit.EchoMode.Password)
        self._ses_region  = QLineEdit(); self._ses_region.setPlaceholderText("us-east-1")
        self._ses_from    = QLineEdit(); self._ses_from.setPlaceholderText("newsletters@yourdomain.com")
        ses_form.addRow("AWS Access Key:", self._ses_access)
        ses_form.addRow("AWS Secret Key:", self._ses_secret)
        ses_form.addRow("Region:", self._ses_region)
        ses_form.addRow("From Email:", self._ses_from)
        ml.addWidget(self._ses_widget)

        # SMTP fields
        self._smtp_widget = QWidget()
        smtp_form = QFormLayout(self._smtp_widget)
        self._smtp_host = QLineEdit(); self._smtp_host.setPlaceholderText("smtp.example.com")
        self._smtp_port = QLineEdit(); self._smtp_port.setText("587")
        self._smtp_user = QLineEdit()
        self._smtp_pass = QLineEdit(); self._smtp_pass.setEchoMode(QLineEdit.EchoMode.Password)
        self._smtp_from = QLineEdit()
        self._smtp_tls  = QCheckBox("Use TLS"); self._smtp_tls.setChecked(True)
        smtp_form.addRow("SMTP Host:", self._smtp_host)
        smtp_form.addRow("Port:", self._smtp_port)
        smtp_form.addRow("Username:", self._smtp_user)
        smtp_form.addRow("Password:", self._smtp_pass)
        smtp_form.addRow("From Email:", self._smtp_from)
        smtp_form.addRow("", self._smtp_tls)
        ml.addWidget(self._smtp_widget)
        self._smtp_widget.setVisible(False)
        layout.addWidget(mail_grp)

        # ── Save ─────────────────────────────────────────────────
        save_row = QHBoxLayout()
        self._save_btn = QPushButton("💾  Save Settings")
        save_row.addStretch()
        save_row.addWidget(self._save_btn)
        layout.addLayout(save_row)

        self._ping_btn.clicked.connect(self._test_connection)
        self._save_btn.clicked.connect(self._save)

    def _on_backend_change(self, idx: int):
        self._ses_widget.setVisible(idx == 0)
        self._smtp_widget.setVisible(idx == 1)

    def _test_connection(self):
        self.api.base_url = self._url_edit.text().strip().rstrip("/")
        self.api.api_key  = self._key_edit.text().strip()
        self._ping_lbl.setText("Testing...")
        self._w = ApiWorker(self.api.ping)
        self._w.result.connect(lambda ok: self._ping_lbl.setText(
            "✓ Connected" if ok else "✗ Failed"
        ))
        self._w.error.connect(lambda e: self._ping_lbl.setText(f"✗ {e}"))
        self._w.start()

    def _save(self):
        # Save server settings locally
        self._qs.setValue("server/url", self._url_edit.text().strip())
        self._qs.setValue("server/key", self._key_edit.text().strip())
        self._qs.setValue("mail/backend", self._backend_combo.currentIndex())
        self._qs.setValue("mail/ses_access",  self._ses_access.text())
        self._qs.setValue("mail/ses_secret",  self._ses_secret.text())
        self._qs.setValue("mail/ses_region",  self._ses_region.text())
        self._qs.setValue("mail/ses_from",    self._ses_from.text())
        self._qs.setValue("mail/smtp_host",   self._smtp_host.text())
        self._qs.setValue("mail/smtp_port",   self._smtp_port.text())
        self._qs.setValue("mail/smtp_user",   self._smtp_user.text())
        self._qs.setValue("mail/smtp_pass",   self._smtp_pass.text())
        self._qs.setValue("mail/smtp_from",   self._smtp_from.text())
        self._qs.setValue("mail/smtp_tls",    self._smtp_tls.isChecked())

        # Push email config to server
        self.api.base_url = self._url_edit.text().strip().rstrip("/")
        self.api.api_key  = self._key_edit.text().strip()

        if self._backend_combo.currentIndex() == 0:
            config = {
                "backend":    "ses",
                "ses_access": self._ses_access.text(),
                "ses_secret": self._ses_secret.text(),
                "ses_region": self._ses_region.text() or "us-east-1",
                "from_email": self._ses_from.text(),
            }
        else:
            config = {
                "backend":    "smtp",
                "smtp_host":  self._smtp_host.text(),
                "smtp_port":  int(self._smtp_port.text() or 587),
                "smtp_user":  self._smtp_user.text(),
                "smtp_pass":  self._smtp_pass.text(),
                "smtp_tls":   self._smtp_tls.isChecked(),
                "from_email": self._smtp_from.text(),
            }

        self._ws = ApiWorker(self.api.put, "/config/email", config)
        self._ws.result.connect(lambda _: QMessageBox.information(self, "Saved", "Settings saved."))
        self._ws.error.connect(lambda e: QMessageBox.critical(self, "Error", f"Server config failed: {e}"))
        self._ws.start()

        self.settings_saved.emit(self.api.base_url, self.api.api_key)

    def _load(self):
        self._url_edit.setText(self._qs.value("server/url", ""))
        self._key_edit.setText(self._qs.value("server/key", ""))
        idx = self._qs.value("mail/backend", 0, type=int)
        self._backend_combo.setCurrentIndex(idx)
        self._ses_access.setText(self._qs.value("mail/ses_access", ""))
        self._ses_secret.setText(self._qs.value("mail/ses_secret", ""))
        self._ses_region.setText(self._qs.value("mail/ses_region", "us-east-1"))
        self._ses_from.setText(self._qs.value("mail/ses_from", ""))
        self._smtp_host.setText(self._qs.value("mail/smtp_host", ""))
        self._smtp_port.setText(self._qs.value("mail/smtp_port", "587"))
        self._smtp_user.setText(self._qs.value("mail/smtp_user", ""))
        self._smtp_pass.setText(self._qs.value("mail/smtp_pass", ""))
        self._smtp_from.setText(self._qs.value("mail/smtp_from", ""))
        self._smtp_tls.setChecked(self._qs.value("mail/smtp_tls", True, type=bool))

        # Restore API client from saved settings
        self.api.base_url = self._url_edit.text().strip().rstrip("/")
        self.api.api_key  = self._key_edit.text().strip()


# ═══════════════════════════════════════════════════════════════════
# Main Window
# ═══════════════════════════════════════════════════════════════════
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME}  v{VERSION}")
        self.setMinimumSize(1100, 700)

        self._qs  = QSettings("Death's Head Software", APP_NAME)
        self._api = APIClient()

        self._tabs = QTabWidget()
        self._dash    = DashboardTab(self._api)
        self._camps   = CampaignsTab(self._api)
        self._contacts= ContactsTab(self._api)
        self._tmpls   = TemplatesTab(self._api)
        self._analyt  = AnalyticsTab(self._api)
        self._settings= SettingsTab(self._api, self._qs)

        self._tabs.addTab(self._dash,     "Dashboard")
        self._tabs.addTab(self._camps,    "Campaigns")
        self._tabs.addTab(self._contacts, "Contacts")
        self._tabs.addTab(self._tmpls,    "Templates")
        self._tabs.addTab(self._analyt,   "Analytics")
        self._tabs.addTab(self._settings, "Settings")
        self._tabs.currentChanged.connect(self._on_tab_change)
        self.setCentralWidget(self._tabs)

        self._status = QStatusBar()
        self.setStatusBar(self._status)
        self._status.showMessage(f"{APP_NAME}  {VERSION}  |  Death's Head Software")

        self._settings.settings_saved.connect(self._on_settings_saved)

        geo = self._qs.value("geometry")
        if geo:
            self.restoreGeometry(geo)

        # Initial load if server already configured
        if self._api.base_url:
            QTimer.singleShot(500, self._initial_refresh)

    def _on_tab_change(self, idx: int):
        tab = self._tabs.widget(idx)
        if hasattr(tab, "refresh"):
            tab.refresh()

    def _on_settings_saved(self, url: str, key: str):
        self._status.showMessage(f"Settings saved  |  Server: {url}")
        self._initial_refresh()

    def _initial_refresh(self):
        self._dash.refresh()

    def closeEvent(self, event):
        self._qs.setValue("geometry", self.saveGeometry())
        super().closeEvent(event)


# ═══════════════════════════════════════════════════════════════════
# Entry point
# ═══════════════════════════════════════════════════════════════════
def main():
    if not HAS_REQUESTS:
        print("Error: 'requests' library not installed. Run: pip install requests")
        sys.exit(1)

    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                "DeathsHeadSoftware.MailOfDeath"
            )
        except Exception:
            pass

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)
    app.setStyle("Fusion")
    app.setStyleSheet(STYLE)

    icon = create_icon()
    app.setWindowIcon(icon)

    splash = create_splash()
    messages = [
        "Initializing...",
        "Loading configuration...",
        "Connecting to server...",
        "Ready.",
    ]
    if splash:
        splash.show()
        for msg in messages:
            splash.showMessage(
                f"\n\n\n\n\n\n\n{msg}",
                Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignHCenter,
                QColor(255, 255, 255),
            )
            app.processEvents()
            time.sleep(0.4)

    win = MainWindow()
    win.show()
    if splash:
        splash.finish(win)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
